/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class contratoTO
/*  4:   */ {
/*  5:   */   String codContrado;
/*  6:   */   String codigocliente;
/*  7:   */   String codigoRegP;
/*  8:   */   int cantidad;
/*  9:   */   double precioActual;
/* 10:   */   double precioNuevo;
/* 11:   */   int periodo;
/* 12:   */   double pago;
/* 13:   */   int letra;
/* 14:   */   String fechapagos;
/* 15:   */   
/* 16:   */   public String getCodContrado()
/* 17:   */   {
/* 18:19 */     return this.codContrado;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setCodContrado(String codContrado)
/* 22:   */   {
/* 23:23 */     this.codContrado = codContrado;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getCodigocliente()
/* 27:   */   {
/* 28:27 */     return this.codigocliente;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setCodigocliente(String codigocliente)
/* 32:   */   {
/* 33:31 */     this.codigocliente = codigocliente;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String getCodigoRegP()
/* 37:   */   {
/* 38:35 */     return this.codigoRegP;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setCodigoRegP(String codigoRegP)
/* 42:   */   {
/* 43:39 */     this.codigoRegP = codigoRegP;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int getCantidad()
/* 47:   */   {
/* 48:43 */     return this.cantidad;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setCantidad(int cantidad)
/* 52:   */   {
/* 53:47 */     this.cantidad = cantidad;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public double getPrecioActual()
/* 57:   */   {
/* 58:51 */     return this.precioActual;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setPrecioActual(double precioActual)
/* 62:   */   {
/* 63:55 */     this.precioActual = precioActual;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public double getPrecioNuevo()
/* 67:   */   {
/* 68:59 */     return this.precioNuevo;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void setPrecioNuevo(double precioNuevo)
/* 72:   */   {
/* 73:63 */     this.precioNuevo = precioNuevo;
/* 74:   */   }
/* 75:   */   
/* 76:   */   public int getPeriodo()
/* 77:   */   {
/* 78:67 */     return this.periodo;
/* 79:   */   }
/* 80:   */   
/* 81:   */   public void setPeriodo(int periodo)
/* 82:   */   {
/* 83:71 */     this.periodo = periodo;
/* 84:   */   }
/* 85:   */   
/* 86:   */   public double getPago()
/* 87:   */   {
/* 88:75 */     return this.pago;
/* 89:   */   }
/* 90:   */   
/* 91:   */   public void setPago(double pago)
/* 92:   */   {
/* 93:79 */     this.pago = pago;
/* 94:   */   }
/* 95:   */   
/* 96:   */   public int getLetra()
/* 97:   */   {
/* 98:83 */     return this.letra;
/* 99:   */   }
/* :0:   */   
/* :1:   */   public void setLetra(int letra)
/* :2:   */   {
/* :3:87 */     this.letra = letra;
/* :4:   */   }
/* :5:   */   
/* :6:   */   public String getFechapagos()
/* :7:   */   {
/* :8:91 */     return this.fechapagos;
/* :9:   */   }
/* ;0:   */   
/* ;1:   */   public void setFechapagos(String fechapagos)
/* ;2:   */   {
/* ;3:95 */     this.fechapagos = fechapagos;
/* ;4:   */   }
/* ;5:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.contratoTO
 * JD-Core Version:    0.7.0.1
 */