/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class detalleventa_TO
/*  4:   */ {
/*  5:   */   String codfactura;
/*  6:   */   String codproducto;
/*  7:   */   String codServ;
/*  8:   */   String codempleado;
/*  9:   */   double precio;
/* 10:   */   double importe;
/* 11:   */   int cantidad;
/* 12:   */   
/* 13:   */   public String getCodfactura()
/* 14:   */   {
/* 15:22 */     return this.codfactura;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setCodfactura(String codfactura)
/* 19:   */   {
/* 20:26 */     this.codfactura = codfactura;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getCodproducto()
/* 24:   */   {
/* 25:30 */     return this.codproducto;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setCodproducto(String codproducto)
/* 29:   */   {
/* 30:34 */     this.codproducto = codproducto;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getCodServ()
/* 34:   */   {
/* 35:38 */     return this.codServ;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setCodServ(String codServ)
/* 39:   */   {
/* 40:42 */     this.codServ = codServ;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String getCodempleado()
/* 44:   */   {
/* 45:46 */     return this.codempleado;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setCodempleado(String codempleado)
/* 49:   */   {
/* 50:50 */     this.codempleado = codempleado;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public double getPrecio()
/* 54:   */   {
/* 55:54 */     return this.precio;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setPrecio(double precio)
/* 59:   */   {
/* 60:58 */     this.precio = precio;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public double getImporte()
/* 64:   */   {
/* 65:62 */     return this.importe;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void setImporte(double importe)
/* 69:   */   {
/* 70:66 */     this.importe = importe;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public int getCantidad()
/* 74:   */   {
/* 75:70 */     return this.cantidad;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public void setCantidad(int cantidad)
/* 79:   */   {
/* 80:74 */     this.cantidad = cantidad;
/* 81:   */   }
/* 82:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.detalleventa_TO
 * JD-Core Version:    0.7.0.1
 */