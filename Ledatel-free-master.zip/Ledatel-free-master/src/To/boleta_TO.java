/*   1:    */ package To;
/*   2:    */ 
/*   3:    */ public class boleta_TO
/*   4:    */ {
/*   5:    */   String codigoFactura;
/*   6:    */   String codigoCliente;
/*   7:    */   String codEmpleado;
/*   8:    */   double igv;
/*   9:    */   double subtotal;
/*  10:    */   double total;
/*  11:    */   String fecha;
/*  12:    */   String estado;
/*  13:    */   String tipoDepago;
/*  14:    */   String ruc;
/*  15:    */   
/*  16:    */   public String getRuc()
/*  17:    */   {
/*  18: 25 */     return this.ruc;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setRuc(String ruc)
/*  22:    */   {
/*  23: 29 */     this.ruc = ruc;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public String getCodEmpleado()
/*  27:    */   {
/*  28: 33 */     return this.codEmpleado;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setCodEmpleado(String codEmpleado)
/*  32:    */   {
/*  33: 37 */     this.codEmpleado = codEmpleado;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getCodigoFactura()
/*  37:    */   {
/*  38: 42 */     return this.codigoFactura;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setCodigoFactura(String codigoFactura)
/*  42:    */   {
/*  43: 46 */     this.codigoFactura = codigoFactura;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getEstado()
/*  47:    */   {
/*  48: 50 */     return this.estado;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setEstado(String estado)
/*  52:    */   {
/*  53: 54 */     this.estado = estado;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getCodigoCliente()
/*  57:    */   {
/*  58: 59 */     return this.codigoCliente;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setCodigoCliente(String codigoCliente)
/*  62:    */   {
/*  63: 63 */     this.codigoCliente = codigoCliente;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public double getIgv()
/*  67:    */   {
/*  68: 67 */     return this.igv;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setIgv(double igv)
/*  72:    */   {
/*  73: 71 */     this.igv = igv;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public double getSubtotal()
/*  77:    */   {
/*  78: 75 */     return this.subtotal;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setSubtotal(double subtotal)
/*  82:    */   {
/*  83: 79 */     this.subtotal = subtotal;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public double getTotal()
/*  87:    */   {
/*  88: 83 */     return this.total;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setTotal(double total)
/*  92:    */   {
/*  93: 87 */     this.total = total;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getFecha()
/*  97:    */   {
/*  98: 91 */     return this.fecha;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void setFecha(String fecha)
/* 102:    */   {
/* 103: 95 */     this.fecha = fecha;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public String getTipoDepago()
/* 107:    */   {
/* 108: 99 */     return this.tipoDepago;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setTipoDepago(String tipoDepago)
/* 112:    */   {
/* 113:103 */     this.tipoDepago = tipoDepago;
/* 114:    */   }
/* 115:    */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.boleta_TO
 * JD-Core Version:    0.7.0.1
 */