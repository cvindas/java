/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class detalleServicios_TO
/*  4:   */ {
/*  5:   */   String codfactura;
/*  6:   */   String codServ;
/*  7:   */   String codempleado;
/*  8:   */   double precio;
/*  9:   */   double importe;
/* 10:   */   int cantidad;
/* 11:   */   
/* 12:   */   public String getCodfactura()
/* 13:   */   {
/* 14:22 */     return this.codfactura;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setCodfactura(String codfactura)
/* 18:   */   {
/* 19:26 */     this.codfactura = codfactura;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getCodServ()
/* 23:   */   {
/* 24:30 */     return this.codServ;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setCodServ(String codServ)
/* 28:   */   {
/* 29:34 */     this.codServ = codServ;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getCodempleado()
/* 33:   */   {
/* 34:38 */     return this.codempleado;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setCodempleado(String codempleado)
/* 38:   */   {
/* 39:42 */     this.codempleado = codempleado;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public double getPrecio()
/* 43:   */   {
/* 44:46 */     return this.precio;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setPrecio(double precio)
/* 48:   */   {
/* 49:50 */     this.precio = precio;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public double getImporte()
/* 53:   */   {
/* 54:54 */     return this.importe;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setImporte(double importe)
/* 58:   */   {
/* 59:58 */     this.importe = importe;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public int getCantidad()
/* 63:   */   {
/* 64:62 */     return this.cantidad;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setCantidad(int cantidad)
/* 68:   */   {
/* 69:66 */     this.cantidad = cantidad;
/* 70:   */   }
/* 71:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.detalleServicios_TO
 * JD-Core Version:    0.7.0.1
 */