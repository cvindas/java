/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class proveedor_TO
/*  4:   */ {
/*  5:   */   String codigo;
/*  6:   */   String empresa;
/*  7:   */   String contacto;
/*  8:   */   String telefono;
/*  9:   */   String direccion;
/* 10:   */   String email;
/* 11:   */   String servicios;
/* 12:   */   String tipo;
/* 13:   */   
/* 14:   */   public String getCodigo()
/* 15:   */   {
/* 16:20 */     return this.codigo;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setCodigo(String codigo)
/* 20:   */   {
/* 21:24 */     this.codigo = codigo;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getEmpresa()
/* 25:   */   {
/* 26:28 */     return this.empresa;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setEmpresa(String empresa)
/* 30:   */   {
/* 31:32 */     this.empresa = empresa;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getContacto()
/* 35:   */   {
/* 36:36 */     return this.contacto;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setTipo(String tipo)
/* 40:   */   {
/* 41:40 */     this.tipo = tipo;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getTipo()
/* 45:   */   {
/* 46:44 */     return this.tipo;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setContacto(String contacto)
/* 50:   */   {
/* 51:48 */     this.contacto = contacto;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public String getTelefono()
/* 55:   */   {
/* 56:52 */     return this.telefono;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setTelefono(String telefono)
/* 60:   */   {
/* 61:56 */     this.telefono = telefono;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public String getDireccion()
/* 65:   */   {
/* 66:60 */     return this.direccion;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setDireccion(String direccion)
/* 70:   */   {
/* 71:64 */     this.direccion = direccion;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public String getEmail()
/* 75:   */   {
/* 76:68 */     return this.email;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setEmail(String email)
/* 80:   */   {
/* 81:72 */     this.email = email;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public String getServicios()
/* 85:   */   {
/* 86:76 */     return this.servicios;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public void setServicios(String servicios)
/* 90:   */   {
/* 91:80 */     this.servicios = servicios;
/* 92:   */   }
/* 93:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.proveedor_TO
 * JD-Core Version:    0.7.0.1
 */