/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class servicio_TO
/*  4:   */ {
/*  5:   */   String factura;
/*  6:   */   String codigo;
/*  7:   */   String observacion;
/*  8:   */   String fecha;
/*  9:   */   String cod_emp;
/* 10:   */   double importe;
/* 11:   */   double precio;
/* 12:   */   double costo;
/* 13:   */   int cantidad;
/* 14:   */   
/* 15:   */   public void setCosto(double costo)
/* 16:   */   {
/* 17:22 */     this.costo = costo;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public double getCosto()
/* 21:   */   {
/* 22:26 */     return this.costo;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getFactura()
/* 26:   */   {
/* 27:30 */     return this.factura;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setFactura(String factura)
/* 31:   */   {
/* 32:34 */     this.factura = factura;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getCod_emp()
/* 36:   */   {
/* 37:38 */     return this.cod_emp;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setCod_emp(String cod_emp)
/* 41:   */   {
/* 42:42 */     this.cod_emp = cod_emp;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public double getPrecio()
/* 46:   */   {
/* 47:46 */     return this.precio;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void setPrecio(double precio)
/* 51:   */   {
/* 52:50 */     this.precio = precio;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int getCantidad()
/* 56:   */   {
/* 57:54 */     return this.cantidad;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void setCantidad(int cantidad)
/* 61:   */   {
/* 62:58 */     this.cantidad = cantidad;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public String getCodigo()
/* 66:   */   {
/* 67:62 */     return this.codigo;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public void setCodigo(String codigo)
/* 71:   */   {
/* 72:66 */     this.codigo = codigo;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String getObservacion()
/* 76:   */   {
/* 77:70 */     return this.observacion;
/* 78:   */   }
/* 79:   */   
/* 80:   */   public void setObservacion(String observacion)
/* 81:   */   {
/* 82:74 */     this.observacion = observacion;
/* 83:   */   }
/* 84:   */   
/* 85:   */   public String getFecha()
/* 86:   */   {
/* 87:78 */     return this.fecha;
/* 88:   */   }
/* 89:   */   
/* 90:   */   public void setFecha(String fecha)
/* 91:   */   {
/* 92:82 */     this.fecha = fecha;
/* 93:   */   }
/* 94:   */   
/* 95:   */   public double getImporte()
/* 96:   */   {
/* 97:86 */     return this.importe;
/* 98:   */   }
/* 99:   */   
/* :0:   */   public void setImporte(double importe)
/* :1:   */   {
/* :2:90 */     this.importe = importe;
/* :3:   */   }
/* :4:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.servicio_TO
 * JD-Core Version:    0.7.0.1
 */