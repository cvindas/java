/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class cliente_TO
/*  4:   */ {
/*  5:   */   String tipo;
/*  6:   */   String codigo;
/*  7:   */   String dni;
/*  8:   */   String datos;
/*  9:   */   String direccion;
/* 10:   */   String celular;
/* 11:   */   String email;
/* 12:   */   String estado;
/* 13:   */   
/* 14:   */   public String getEstado()
/* 15:   */   {
/* 16:20 */     return this.estado;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setEstado(String estado)
/* 20:   */   {
/* 21:24 */     this.estado = estado;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getTipo()
/* 25:   */   {
/* 26:29 */     return this.tipo;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setTipo(String tipo)
/* 30:   */   {
/* 31:33 */     this.tipo = tipo;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getCelular()
/* 35:   */   {
/* 36:37 */     return this.celular;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setCelular(String celular)
/* 40:   */   {
/* 41:41 */     this.celular = celular;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getEmail()
/* 45:   */   {
/* 46:45 */     return this.email;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setEmail(String email)
/* 50:   */   {
/* 51:49 */     this.email = email;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public String getCodigo()
/* 55:   */   {
/* 56:53 */     return this.codigo;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setCodigo(String codigo)
/* 60:   */   {
/* 61:57 */     this.codigo = codigo;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public String getDni()
/* 65:   */   {
/* 66:61 */     return this.dni;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setDni(String dni)
/* 70:   */   {
/* 71:65 */     this.dni = dni;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public String getDatos()
/* 75:   */   {
/* 76:69 */     return this.datos;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setDatos(String datos)
/* 80:   */   {
/* 81:73 */     this.datos = datos;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public String getDireccion()
/* 85:   */   {
/* 86:77 */     return this.direccion;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public void setDireccion(String direccion)
/* 90:   */   {
/* 91:81 */     this.direccion = direccion;
/* 92:   */   }
/* 93:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.cliente_TO
 * JD-Core Version:    0.7.0.1
 */