/*   1:    */ package To;
/*   2:    */ 
/*   3:    */ public class empleado_TO
/*   4:    */ {
/*   5:    */   String codigoempleado;
/*   6:    */   String DNI;
/*   7:    */   String apellidos;
/*   8:    */   String nombres;
/*   9:    */   String sexo;
/*  10:    */   String direccion;
/*  11:    */   String correo;
/*  12:    */   String telefono;
/*  13:    */   String estado;
/*  14:    */   String id;
/*  15:    */   String contraseña;
/*  16:    */   String tipoUsuario;
/*  17:    */   double sueldo;
/*  18:    */   
/*  19:    */   public String getCodigoempleado()
/*  20:    */   {
/*  21: 20 */     return this.codigoempleado;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public double getSueldo()
/*  25:    */   {
/*  26: 24 */     return this.sueldo;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setSueldo(double sueldo)
/*  30:    */   {
/*  31: 28 */     this.sueldo = sueldo;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setCodigoempleado(String codigoempleado)
/*  35:    */   {
/*  36: 33 */     this.codigoempleado = codigoempleado;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public String getDNI()
/*  40:    */   {
/*  41: 37 */     return this.DNI;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setDNI(String DNI)
/*  45:    */   {
/*  46: 41 */     this.DNI = DNI;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public String getApellidos()
/*  50:    */   {
/*  51: 45 */     return this.apellidos;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setApellidos(String apellidos)
/*  55:    */   {
/*  56: 49 */     this.apellidos = apellidos;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String getNombres()
/*  60:    */   {
/*  61: 53 */     return this.nombres;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setNombres(String nombres)
/*  65:    */   {
/*  66: 57 */     this.nombres = nombres;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getSexo()
/*  70:    */   {
/*  71: 61 */     return this.sexo;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setSexo(String sexo)
/*  75:    */   {
/*  76: 65 */     this.sexo = sexo;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String getDireccion()
/*  80:    */   {
/*  81: 69 */     return this.direccion;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setDireccion(String direccion)
/*  85:    */   {
/*  86: 73 */     this.direccion = direccion;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String getCorreo()
/*  90:    */   {
/*  91: 77 */     return this.correo;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setCorreo(String correo)
/*  95:    */   {
/*  96: 81 */     this.correo = correo;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getTelefono()
/* 100:    */   {
/* 101: 85 */     return this.telefono;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setTelefono(String telefono)
/* 105:    */   {
/* 106: 89 */     this.telefono = telefono;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public String getEstado()
/* 110:    */   {
/* 111: 93 */     return this.estado;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setEstado(String estado)
/* 115:    */   {
/* 116: 97 */     this.estado = estado;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public String getId()
/* 120:    */   {
/* 121:101 */     return this.id;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setId(String id)
/* 125:    */   {
/* 126:105 */     this.id = id;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public String getContraseña()
/* 130:    */   {
/* 131:109 */     return this.contraseña;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setContraseña(String contraseña)
/* 135:    */   {
/* 136:113 */     this.contraseña = contraseña;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getTipoUsuario()
/* 140:    */   {
/* 141:117 */     return this.tipoUsuario;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setTipoUsuario(String tipoUsuario)
/* 145:    */   {
/* 146:121 */     this.tipoUsuario = tipoUsuario;
/* 147:    */   }
/* 148:    */ }



/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar

 * Qualified Name:     To.empleado_TO

 * JD-Core Version:    0.7.0.1

 */