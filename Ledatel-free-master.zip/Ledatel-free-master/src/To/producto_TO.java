/*   1:    */ package To;
/*   2:    */ 
/*   3:    */ public class producto_TO
/*   4:    */ {
/*   5:    */   String codigoProd;
/*   6:    */   String marca;
/*   7:    */   String modelo;
/*   8:    */   String proveedor;
/*   9:    */   String tipo;
/*  10:    */   String fechaEmision;
/*  11:    */   String descripcion;
/*  12:    */   String estado;
/*  13:    */   double precioCpmpra;
/*  14:    */   double precioVenta;
/*  15:    */   int stock;
/*  16:    */   
/*  17:    */   public String getCodigoProd()
/*  18:    */   {
/*  19: 23 */     return this.codigoProd;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setCodigoProd(String codigoProd)
/*  23:    */   {
/*  24: 27 */     this.codigoProd = codigoProd;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setEstado(String estado)
/*  28:    */   {
/*  29: 31 */     this.estado = estado;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getEstado()
/*  33:    */   {
/*  34: 35 */     return this.estado;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public String getMarca()
/*  38:    */   {
/*  39: 39 */     return this.marca;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setMarca(String marca)
/*  43:    */   {
/*  44: 43 */     this.marca = marca;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String getModelo()
/*  48:    */   {
/*  49: 47 */     return this.modelo;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setModelo(String modelo)
/*  53:    */   {
/*  54: 51 */     this.modelo = modelo;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getProveedor()
/*  58:    */   {
/*  59: 55 */     return this.proveedor;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setProveedor(String proveedor)
/*  63:    */   {
/*  64: 59 */     this.proveedor = proveedor;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getTipo()
/*  68:    */   {
/*  69: 65 */     return this.tipo;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setTipo(String tipo)
/*  73:    */   {
/*  74: 69 */     this.tipo = tipo;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getFechaEmision()
/*  78:    */   {
/*  79: 73 */     return this.fechaEmision;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setFechaEmision(String fechaEmision)
/*  83:    */   {
/*  84: 77 */     this.fechaEmision = fechaEmision;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String getDescripcion()
/*  88:    */   {
/*  89: 81 */     return this.descripcion;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setDescripcion(String descripcion)
/*  93:    */   {
/*  94: 85 */     this.descripcion = descripcion;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public double getPrecioCpmpra()
/*  98:    */   {
/*  99: 90 */     return this.precioCpmpra;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setPrecioCpmpra(double precioCpmpra)
/* 103:    */   {
/* 104: 94 */     this.precioCpmpra = precioCpmpra;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public double getPrecioVenta()
/* 108:    */   {
/* 109: 98 */     return this.precioVenta;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setPrecioVenta(double precioVenta)
/* 113:    */   {
/* 114:102 */     this.precioVenta = precioVenta;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public int getStock()
/* 118:    */   {
/* 119:114 */     return this.stock;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setStock(int stock)
/* 123:    */   {
/* 124:118 */     this.stock = stock;
/* 125:    */   }
/* 126:    */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.producto_TO
 * JD-Core Version:    0.7.0.1
 */