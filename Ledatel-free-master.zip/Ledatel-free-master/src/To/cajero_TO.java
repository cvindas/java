/*  1:   */ package To;
/*  2:   */ 
/*  3:   */ public class cajero_TO
/*  4:   */ {
/*  5:   */   double incio;
/*  6:   */   double compras;
/*  7:   */   double ventas;
/*  8:   */   double reparaciones;
/*  9:   */   double nuevoSaldo;
/* 10:   */   String fecha;
/* 11:   */   String hrFinal;
/* 12:   */   
/* 13:   */   public double getIncio()
/* 14:   */   {
/* 15:21 */     return this.incio;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public String getHrFinal()
/* 19:   */   {
/* 20:25 */     return this.hrFinal;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setHrFinal(String hrFinal)
/* 24:   */   {
/* 25:29 */     this.hrFinal = hrFinal;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setIncio(double incio)
/* 29:   */   {
/* 30:34 */     this.incio = incio;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public double getCompras()
/* 34:   */   {
/* 35:38 */     return this.compras;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setCompras(double compras)
/* 39:   */   {
/* 40:42 */     this.compras = compras;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public double getVentas()
/* 44:   */   {
/* 45:46 */     return this.ventas;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setVentas(double ventas)
/* 49:   */   {
/* 50:50 */     this.ventas = ventas;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public double getReparaciones()
/* 54:   */   {
/* 55:54 */     return this.reparaciones;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setReparaciones(double reparaciones)
/* 59:   */   {
/* 60:58 */     this.reparaciones = reparaciones;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public double getNuevoSaldo()
/* 64:   */   {
/* 65:62 */     return this.nuevoSaldo;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void setNuevoSaldo(double nuevoSaldo)
/* 69:   */   {
/* 70:66 */     this.nuevoSaldo = nuevoSaldo;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public String getFecha()
/* 74:   */   {
/* 75:70 */     return this.fecha;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public void setFecha(String fecha)
/* 79:   */   {
/* 80:74 */     this.fecha = fecha;
/* 81:   */   }
/* 82:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     To.cajero_TO
 * JD-Core Version:    0.7.0.1
 */