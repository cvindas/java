/*  1:   */ package Log_Reporte;
/*  2:   */ 
/*  3:   */ public class reporte_cajaCompras
/*  4:   */ {
/*  5:   */   String codigoroducto;
/*  6:   */   String marca;
/*  7:   */   String serie;
/*  8:   */   double costo;
/*  9:   */   int cantidad;
/* 10:   */   String sociedad;
/* 11:   */   String estado;
/* 12:   */   
/* 13:   */   public reporte_cajaCompras(String codigoroducto, String marca, String serie, double costo, int cantidad, String sociedad, String estado)
/* 14:   */   {
/* 15:20 */     this.codigoroducto = codigoroducto;
/* 16:21 */     this.marca = marca;
/* 17:22 */     this.serie = serie;
/* 18:23 */     this.costo = costo;
/* 19:24 */     this.cantidad = cantidad;
/* 20:25 */     this.sociedad = sociedad;
/* 21:26 */     this.estado = estado;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getCodigoroducto()
/* 25:   */   {
/* 26:33 */     return this.codigoroducto;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setCodigoroducto(String codigoroducto)
/* 30:   */   {
/* 31:37 */     this.codigoroducto = codigoroducto;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getMarca()
/* 35:   */   {
/* 36:41 */     return this.marca;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setMarca(String marca)
/* 40:   */   {
/* 41:45 */     this.marca = marca;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getSerie()
/* 45:   */   {
/* 46:49 */     return this.serie;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setSerie(String serie)
/* 50:   */   {
/* 51:53 */     this.serie = serie;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public double getCosto()
/* 55:   */   {
/* 56:57 */     return this.costo;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setCosto(double costo)
/* 60:   */   {
/* 61:61 */     this.costo = costo;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public int getCantidad()
/* 65:   */   {
/* 66:65 */     return this.cantidad;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setCantidad(int cantidad)
/* 70:   */   {
/* 71:69 */     this.cantidad = cantidad;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public String getSociedad()
/* 75:   */   {
/* 76:73 */     return this.sociedad;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setSociedad(String sociedad)
/* 80:   */   {
/* 81:77 */     this.sociedad = sociedad;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public String getEstado()
/* 85:   */   {
/* 86:81 */     return this.estado;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public void setEstado(String estado)
/* 90:   */   {
/* 91:85 */     this.estado = estado;
/* 92:   */   }
/* 93:   */ }


/* Location:           E:\Proyect\Java\LEDATEL\dist\LEDATEL.jar
 * Qualified Name:     Log_Reporte.reporte_cajaCompras
 * JD-Core Version:    0.7.0.1
 */